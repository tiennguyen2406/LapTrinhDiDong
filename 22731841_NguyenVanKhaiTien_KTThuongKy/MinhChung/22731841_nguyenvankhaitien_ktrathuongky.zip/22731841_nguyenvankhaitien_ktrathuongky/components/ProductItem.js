import { View, Text, Button, StyleSheet } from "react-native";

export default function ProductItem({ product, onAddToCart }) {
  return (
    <View style={styles.item}>
      <Text style={styles.name}>{product.name}</Text>
      <Text style={styles.price}>{product.price} VND</Text>
      <Button title="Them vao gio hang" onPress={() => onAddToCart(product)} />
    </View>
  );
}


const styles = StyleSheet.create({
  item: {
    padding: 16,
    marginVertical: 8,
    backgroundColor: "grey",
    borderRadius: 8,
    marginLeft:20,
    marginRight: 20
  },
  name: { fontSize: 18, fontWeight: "bold" },
  price: { fontSize: 14, marginBottom: 8 },
});