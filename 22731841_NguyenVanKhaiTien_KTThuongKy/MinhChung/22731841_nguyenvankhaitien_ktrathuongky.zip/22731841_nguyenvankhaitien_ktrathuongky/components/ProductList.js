import { FlatList } from "react-native";
import ProductItem from "./ProductItem";

export default function ProductList({ products, onAddToCart }) {
  return (
    <FlatList
      data={products}
      key={(item) => item.id}
      renderItem={({ item }) => (
        <ProductItem product={item} onAddToCart={onAddToCart} />
      )}
    />
  );
}