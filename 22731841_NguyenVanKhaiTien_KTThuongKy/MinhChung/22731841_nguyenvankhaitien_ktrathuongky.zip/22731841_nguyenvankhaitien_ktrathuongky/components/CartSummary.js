import React from "react";
import { View, Text, StyleSheet } from "react-native";

export default function CartSummary({ count, total }) {
  return (
    <View style={styles.summary}>
      <Text style={styles.text}>
        {count} san pham| Tong tien: {total} VND
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  summary: { padding: 12, backgroundColor: "grey", marginBottom: 20,marginTop:5, borderRadius: 8 },
  text: { fontSize: 16, fontWeight: "bold" },
});