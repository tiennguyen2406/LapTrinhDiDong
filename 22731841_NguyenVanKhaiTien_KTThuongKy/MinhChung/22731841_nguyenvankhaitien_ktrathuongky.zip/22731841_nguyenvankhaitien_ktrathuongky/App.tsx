import React, { useState } from "react";
import { SafeAreaView, StyleSheet, View } from "react-native";
import ProductList from "./components/ProductList";
import CartSummary from "./components/CartSummary";

const products = [
  { id: "1", name: "Ao so mi", price: 240000 },
  { id: "2", name: "Quan Tay", price: 120000 },
  { id: "3", name: "Giay da banh", price: 500000 },
  { id: "4",name : "mu luoi trai", price: 100000},
  { id: "5", name :"ao thun", price : 50000}
];

export default function App() {
  const [cart, setCart] = useState([]);

  const handleAddToCart = (product) => {
    setCart([...cart, product]);
  };

  const total = cart.reduce((sum, item) => sum + item.price, 0);

  return (
    <SafeAreaView style={styles.container}>
      <CartSummary count={cart.length} total={total} />
      <View style={{ flex: 1 }}>
        <ProductList products={products} onAddToCart={handleAddToCart} />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: "white" },
});